using UnityEngine;
using UnityEngine.SceneManagement;

public class bob : MonoBehaviour
{
    public float velocidade = 5f;
    private Rigidbody2D rb;
    private float movimento;
    private int moedas = 0;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        movimento = Input.GetAxis("Horizontal");
        if (Input.GetKeyDown(KeyCode.Space))
        {
           rb.AddForce(Vector2.up * 10, ForceMode2D.Impulse);

        }
    }


     void OnCollisionEnter2D(Collision2D collision) 
    {
        if (collision.gameObject.CompareTag("Inimigo")){
            Destroy(gameObject);
        }
        if (collision.gameObject.CompareTag("Item")){
            Destroy(collision.gameObject);
            moedas ++;
            if(moedas>=11)
            {
                SceneManager.LoadSceneAsync("SampleScene");
            }
        }
    }




    void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(movimento * velocidade, rb.linearVelocity.y);
    }
}